package com.utp.Celumax;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CelumaxApplication {

	public static void main(String[] args) {
		SpringApplication.run(CelumaxApplication.class, args);
	}

}
